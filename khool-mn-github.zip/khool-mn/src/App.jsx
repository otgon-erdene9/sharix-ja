import React, { useState, useMemo } from 'react'
import Header from './components/Header'
import Hero from './components/Hero'
import RecipeCard from './components/RecipeCard'
import Modal from './components/Modal'
import FoodImage from './components/FoodImage'
import { RECIPES, CATEGORIES } from './data/recipes'

const s = {
  filterBar: {
    background: 'var(--surface)',
    borderTop: '1px solid var(--border)',
    borderBottom: '1px solid var(--border)',
    overflowX: 'auto',
  },
  filterInner: {
    maxWidth: 1100, margin: '0 auto',
    padding: '0 1.5rem', display: 'flex',
  },
  section: { padding: '4rem 0' },
  sectionWarm: { padding: '4rem 0', background: 'var(--bg-warm)' },
  container: { maxWidth: 1100, margin: '0 auto', padding: '0 1.5rem' },
  sectionHeader: { display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' },
  sectionTitle: {
    fontFamily: 'var(--font-display)',
    fontSize: 28, fontWeight: 700, color: 'var(--text-1)', whiteSpace: 'nowrap',
  },
  sectionLine: { flex: 1, height: 1, background: 'var(--border)' },
  featuredGrid: {
    display: 'grid',
    gridTemplateColumns: '1.4fr 1fr',
    gap: '1.25rem', alignItems: 'start',
  },
  featuredSide: { display: 'flex', flexDirection: 'column', gap: '1.25rem' },
  recipeGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(300px,1fr))',
    gap: '1.5rem',
  },
  noResults: { textAlign: 'center', padding: '4rem', color: 'var(--text-3)' },
  footer: { background: 'var(--text-1)', padding: '3rem 0' },
  footerInner: { maxWidth: 1100, margin: '0 auto', padding: '0 1.5rem', textAlign: 'center' },
  footerLogo: {
    fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700,
    color: 'white', marginBottom: '0.75rem',
  },
  footerText: { color: 'rgba(255,255,255,0.5)', fontSize: 14, marginBottom: '0.5rem' },
  footerCopy: { color: 'rgba(255,255,255,0.25)', fontSize: 12 },
}

function FilterBtn({ cat, active, onClick }) {
  const [hov, setHov] = useState(false)
  const style = {
    background: 'none', border: 'none',
    fontFamily: 'var(--font-body)', fontSize: 14, fontWeight: 500,
    color: active ? 'var(--accent)' : hov ? 'var(--text-1)' : 'var(--text-2)',
    padding: '14px 18px', cursor: 'pointer', whiteSpace: 'nowrap',
    borderBottom: `2px solid ${active ? 'var(--accent)' : 'transparent'}`,
    transition: 'all 0.2s',
  }
  return (
    <button
      style={style}
      onClick={onClick}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
    >
      {cat.emoji} {cat.label}
    </button>
  )
}

export default function App() {
  const [search, setSearch] = useState('')
  const [activeFilter, setActiveFilter] = useState('all')
  const [selectedRecipe, setSelectedRecipe] = useState(null)

  const featured = RECIPES.filter(r => r.featured)
  const heroRecipe = RECIPES[0]

  const filtered = useMemo(() => {
    return RECIPES.filter(r => {
      const matchCat = activeFilter === 'all' || r.category === activeFilter
      const matchSearch = !search || r.name.toLowerCase().includes(search.toLowerCase())
      return matchCat && matchSearch
    })
  }, [activeFilter, search])

  return (
    <>
      <Header search={search} onSearch={setSearch} />

      <Hero featuredRecipe={heroRecipe} onOpenModal={setSelectedRecipe} />

      {/* Category Filter */}
      <div style={s.filterBar} id="categories">
        <div style={s.filterInner}>
          {CATEGORIES.map(cat => (
            <FilterBtn
              key={cat.id}
              cat={cat}
              active={activeFilter === cat.id}
              onClick={() => setActiveFilter(cat.id)}
            />
          ))}
        </div>
      </div>

      {/* Featured Section */}
      {activeFilter === 'all' && !search && (
        <section style={s.section} id="featured">
          <div style={s.container}>
            <div style={s.sectionHeader}>
              <h2 style={s.sectionTitle}>Онцлох жорнууд</h2>
              <span style={s.sectionLine} />
            </div>
            <div style={s.featuredGrid}>
              <RecipeCard recipe={featured[0]} onOpen={setSelectedRecipe} size="big" />
              <div style={s.featuredSide}>
                {featured.slice(1).map(r => (
                  <RecipeCard key={r.id} recipe={r} onOpen={setSelectedRecipe} />
                ))}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* All Recipes */}
      <section style={s.sectionWarm} id="all">
        <div style={s.container}>
          <div style={s.sectionHeader}>
            <h2 style={s.sectionTitle}>
              {search ? `"${search}" хайлтын үр дүн` : 'Бүх жорнууд'}
            </h2>
            <span style={s.sectionLine} />
          </div>
          {filtered.length > 0 ? (
            <div style={s.recipeGrid}>
              {filtered.map(r => (
                <RecipeCard key={r.id} recipe={r} onOpen={setSelectedRecipe} />
              ))}
            </div>
          ) : (
            <div style={s.noResults}>
              <p style={{ fontSize: '3rem', marginBottom: '1rem' }}>🔍</p>
              <p>"{search}" хоол олдсонгүй.</p>
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer style={s.footer}>
        <div style={s.footerInner}>
          <div style={s.footerLogo}>Хоол<span style={{ color: 'var(--accent)' }}>.</span>МН</div>
          <p style={s.footerText}>Монголын шилдэг хоолны жорны платформ</p>
          <p style={s.footerCopy}>© 2025 Хоол.МН — Бүх эрх хамгаалагдсан</p>
        </div>
      </footer>

      {/* Modal */}
      {selectedRecipe && (
        <Modal recipe={selectedRecipe} onClose={() => setSelectedRecipe(null)} />
      )}
    </>
  )
}
