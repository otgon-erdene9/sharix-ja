import React from 'react'

const s = {
  header: {
    position: 'sticky', top: 0, zIndex: 100,
    background: 'rgba(255,255,255,0.96)',
    backdropFilter: 'blur(12px)',
    borderBottom: '1px solid var(--border)',
  },
  inner: {
    maxWidth: 1100, margin: '0 auto',
    padding: '0 1.5rem',
    display: 'flex', alignItems: 'center',
    gap: '1.5rem', height: 64,
  },
  logo: {
    fontFamily: 'var(--font-display)',
    fontSize: 24, fontWeight: 700,
    color: 'var(--text-1)',
    letterSpacing: '-0.5px',
    whiteSpace: 'nowrap',
    textDecoration: 'none',
  },
  dot: { color: 'var(--accent)' },
  searchWrap: {
    flex: 1, maxWidth: 340,
    display: 'flex', alignItems: 'center', gap: 8,
    background: 'var(--bg-warm)',
    border: '1px solid var(--border)',
    borderRadius: 40, padding: '8px 16px',
  },
  input: {
    border: 'none', background: 'transparent',
    fontFamily: 'var(--font-body)', fontSize: 14,
    color: 'var(--text-1)', outline: 'none', width: '100%',
  },
  nav: { display: 'flex', gap: '1.5rem', marginLeft: 'auto' },
  navLink: {
    fontSize: 14, fontWeight: 500,
    color: 'var(--text-2)', textDecoration: 'none',
    transition: 'color 0.2s',
  },
}

export default function Header({ search, onSearch }) {
  return (
    <header style={s.header}>
      <div style={s.inner}>
        <a href="#top" style={s.logo}>
          Хоол<span style={s.dot}>.</span>МН
        </a>
        <div style={s.searchWrap}>
          <svg width="15" height="15" fill="none" stroke="var(--text-3)" strokeWidth="2" viewBox="0 0 24 24">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <input
            style={s.input}
            type="text"
            placeholder="Хоол хайх..."
            value={search}
            onChange={e => onSearch(e.target.value)}
          />
        </div>
        <nav style={s.nav}>
          <a href="#featured" style={s.navLink} onMouseOver={e=>e.target.style.color='var(--accent)'} onMouseOut={e=>e.target.style.color='var(--text-2)'}>Онцлох</a>
          <a href="#all" style={s.navLink} onMouseOver={e=>e.target.style.color='var(--accent)'} onMouseOut={e=>e.target.style.color='var(--text-2)'}>Бүх жор</a>
        </nav>
      </div>
    </header>
  )
}
