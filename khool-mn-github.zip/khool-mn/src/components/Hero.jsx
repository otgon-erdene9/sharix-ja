import React from 'react'
import FoodImage from './FoodImage'

const s = {
  hero: {
    maxWidth: 1100, margin: '0 auto',
    padding: '4rem 1.5rem 3rem',
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '3rem', alignItems: 'center',
  },
  eyebrow: {
    fontSize: 12, fontWeight: 500,
    color: 'var(--accent)',
    textTransform: 'uppercase', letterSpacing: '1.5px',
    marginBottom: '1rem',
  },
  title: {
    fontFamily: 'var(--font-display)',
    fontSize: 'clamp(36px,5vw,56px)',
    fontWeight: 700, lineHeight: 1.1,
    color: 'var(--text-1)', marginBottom: '1.25rem',
  },
  em: { fontStyle: 'italic', color: 'var(--accent)' },
  sub: {
    fontSize: 16, color: 'var(--text-2)',
    marginBottom: '2rem', lineHeight: 1.7, maxWidth: 420,
  },
  stats: { display: 'flex', alignItems: 'center', gap: '1.5rem' },
  stat: { display: 'flex', flexDirection: 'column' },
  statNum: {
    fontFamily: 'var(--font-display)',
    fontSize: 28, fontWeight: 700, color: 'var(--accent)', lineHeight: 1,
  },
  statLabel: { fontSize: 12, color: 'var(--text-3)', marginTop: 2 },
  sep: { width: 1, height: 36, background: 'var(--border)' },
  imgWrap: {
    position: 'relative', borderRadius: 'var(--radius-lg)',
    overflow: 'hidden', aspectRatio: '4/3',
    boxShadow: 'var(--shadow-lg)',
    background: 'linear-gradient(135deg, #7B1C00, #C0392B)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  },
  badge: {
    position: 'absolute', top: 16, right: 16,
    background: 'var(--accent)', color: 'white',
    fontSize: 12, fontWeight: 500,
    padding: '6px 14px', borderRadius: 20,
  },
  heroImgBg: {
    position: 'absolute', inset: 0,
    background: 'radial-gradient(circle at 60% 40%, rgba(255,255,255,0.08), transparent 70%)',
  },
}

export default function Hero({ featuredRecipe, onOpenModal }) {
  return (
    <section style={s.hero} id="top">
      <div>
        <p style={s.eyebrow}>Монгол болон дэлхийн хоолны жорнууд</p>
        <h1 style={s.title}>
          Өнөөдөр юу<br /><em style={s.em}>хийх вэ?</em>
        </h1>
        <p style={s.sub}>
          Шилдэг жорнуудыг нэг дороос олж, гэртээ хялбараар хоол хийнэ үү.
        </p>
        <div style={s.stats}>
          <div style={s.stat}>
            <span style={s.statNum}>9+</span>
            <span style={s.statLabel}>Жор</span>
          </div>
          <div style={s.sep} />
          <div style={s.stat}>
            <span style={s.statNum}>4</span>
            <span style={s.statLabel}>Ангилал</span>
          </div>
          <div style={s.sep} />
          <div style={s.stat}>
            <span style={s.statNum}>100%</span>
            <span style={s.statLabel}>Монгол</span>
          </div>
        </div>
      </div>

      <div
        style={s.imgWrap}
        onClick={() => onOpenModal(featuredRecipe)}
        role="button"
        tabIndex={0}
        onKeyDown={e => e.key === 'Enter' && onOpenModal(featuredRecipe)}
        aria-label={`${featuredRecipe.name} харах`}
      >
        <div style={s.heroImgBg} />
        <FoodImage recipe={featuredRecipe} size={200} />
        <div style={s.badge}>⭐ Онцлох хоол</div>
      </div>
    </section>
  )
}
