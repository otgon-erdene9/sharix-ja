import React, { useState } from 'react'
import FoodImage from './FoodImage'

const diffColor = {
  'Маш хялбар': { bg: '#E8F5E9', color: '#2E7D32' },
  'Хялбар':     { bg: '#E8F5E9', color: '#2E7D32' },
  'Дунд':       { bg: '#FFF3E0', color: '#E65100' },
  'Хэцүү':      { bg: '#FFEBEE', color: '#C62828' },
}

export default function RecipeCard({ recipe, onOpen, size = 'normal' }) {
  const [hovered, setHovered] = useState(false)
  const dc = diffColor[recipe.diff] || diffColor['Дунд']
  const isBig = size === 'big'

  const cardStyle = {
    background: 'var(--surface)',
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius-lg)',
    overflow: 'hidden', cursor: 'pointer',
    transition: 'transform 0.25s, box-shadow 0.25s',
    transform: hovered ? 'translateY(-4px)' : 'none',
    boxShadow: hovered ? 'var(--shadow-md)' : 'var(--shadow-sm)',
    display: 'flex', flexDirection: isBig ? 'column' : 'column',
  }

  const imgWrap = {
    position: 'relative', overflow: 'hidden',
    background: `linear-gradient(135deg, ${recipe.color[0]}, ${recipe.color[1]})`,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    height: isBig ? 240 : 170,
  }

  const overlay = {
    position: 'absolute', inset: 0,
    background: 'linear-gradient(to top, rgba(0,0,0,0.65) 0%, rgba(0,0,0,0.05) 55%, transparent 100%)',
    display: 'flex', flexDirection: 'column', justifyContent: 'flex-end',
    padding: '1rem',
  }

  return (
    <div
      style={cardStyle}
      onClick={() => onOpen(recipe)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      role="button"
      tabIndex={0}
      onKeyDown={e => e.key === 'Enter' && onOpen(recipe)}
      aria-label={recipe.name}
    >
      <div style={imgWrap}>
        <div style={{
          position: 'absolute', inset: 0,
          background: 'radial-gradient(circle at 40% 35%, rgba(255,255,255,0.1), transparent 65%)',
        }}/>
        <FoodImage recipe={recipe} size={isBig ? 130 : 90} />
        <div style={overlay}>
          <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.75)', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: 4 }}>
            {recipe.categoryLabel}
          </span>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: isBig ? 22 : 18, fontWeight: 700, color: 'white', marginBottom: 4 }}>
            {recipe.name}
          </h3>
          <div style={{ display: 'flex', gap: 12, fontSize: 12, color: 'rgba(255,255,255,0.8)' }}>
            <span>⏱ {recipe.time}</span>
            <span>👥 {recipe.serves}</span>
          </div>
        </div>
        {recipe.featured && (
          <div style={{
            position: 'absolute', top: 12, left: 12,
            background: 'var(--accent)', color: 'white',
            fontSize: 11, fontWeight: 500,
            padding: '4px 10px', borderRadius: 20,
          }}>🔥 Онцлох</div>
        )}
      </div>
      <div style={{ padding: '1rem 1.25rem 1.25rem' }}>
        <p style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.55, marginBottom: '0.875rem' }}>
          {recipe.desc}
        </p>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontSize: 12, color: 'var(--text-3)' }}>🥗 {recipe.calories}</span>
          <span style={{
            fontSize: 11, fontWeight: 500,
            padding: '3px 10px', borderRadius: 20,
            background: dc.bg, color: dc.color,
          }}>{recipe.diff}</span>
        </div>
      </div>
    </div>
  )
}
