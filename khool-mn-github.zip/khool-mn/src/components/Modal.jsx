import React, { useEffect } from 'react'
import FoodImage from './FoodImage'

const s = {
  overlay: {
    position: 'fixed', inset: 0,
    background: 'rgba(0,0,0,0.6)',
    zIndex: 500, display: 'flex',
    alignItems: 'center', justifyContent: 'center',
    padding: '1rem',
    backdropFilter: 'blur(4px)',
  },
  modal: {
    background: 'var(--surface)',
    borderRadius: 'var(--radius-lg)',
    width: '100%', maxWidth: 720,
    maxHeight: '90vh', overflowY: 'auto',
    position: 'relative',
    boxShadow: 'var(--shadow-lg)',
    animation: 'slideUp 0.28s ease',
  },
  closeBtn: {
    position: 'absolute', top: 12, right: 12, zIndex: 10,
    width: 34, height: 34, borderRadius: '50%',
    background: 'rgba(0,0,0,0.5)', color: 'white',
    border: 'none', cursor: 'pointer',
    fontSize: 16, display: 'flex',
    alignItems: 'center', justifyContent: 'center',
  },
  imgBanner: {
    height: 200, display: 'flex', alignItems: 'center', justifyContent: 'center',
    position: 'relative', overflow: 'hidden',
    borderRadius: 'var(--radius-lg) var(--radius-lg) 0 0',
  },
  imgOverlay: {
    position: 'absolute', inset: 0,
    background: 'linear-gradient(to top, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.05) 55%, transparent 100%)',
    display: 'flex', flexDirection: 'column',
    justifyContent: 'flex-end', padding: '1.5rem',
  },
  tag: { fontSize: 11, color: 'rgba(255,255,255,0.75)', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: 6 },
  title: { fontFamily: 'var(--font-display)', fontSize: 30, fontWeight: 700, color: 'white' },
  body: { padding: '1.5rem' },
  metaRow: { display: 'flex', gap: '1.5rem', marginBottom: '1.5rem', flexWrap: 'wrap' },
  metaItem: { fontSize: 14, color: 'var(--text-2)' },
  cols: { display: 'grid', gridTemplateColumns: '1fr 1.3fr', gap: '2rem', marginBottom: '1.5rem' },
  sectionTitle: {
    fontSize: 11, fontWeight: 500, color: 'var(--text-3)',
    textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '0.875rem',
  },
  ingrList: { listStyle: 'none' },
  ingrItem: {
    fontSize: 14, color: 'var(--text-1)',
    padding: '7px 0', borderBottom: '1px solid var(--border)',
    display: 'flex', alignItems: 'center', gap: 10,
  },
  dot: { width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)', flexShrink: 0 },
  stepList: { listStyle: 'none' },
  stepItem: {
    fontSize: 14, color: 'var(--text-1)',
    padding: '9px 0', borderBottom: '1px solid var(--border)',
    display: 'flex', gap: 12, alignItems: 'flex-start',
  },
  stepNum: {
    width: 24, height: 24, borderRadius: '50%',
    background: 'var(--accent)', color: 'white',
    fontSize: 12, fontWeight: 500, display: 'flex',
    alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1,
  },
  tip: {
    padding: '1rem 1.25rem',
    background: 'var(--accent-light)',
    borderRadius: 'var(--radius-md)',
    borderLeft: '3px solid var(--accent)',
    fontSize: 13, color: 'var(--accent-dark)',
  },
}

export default function Modal({ recipe, onClose }) {
  useEffect(() => {
    const handler = e => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', handler)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', handler)
      document.body.style.overflow = ''
    }
  }, [onClose])

  if (!recipe) return null

  return (
    <>
      <style>{`@keyframes slideUp { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }`}</style>
      <div style={s.overlay} onClick={e => e.target === e.currentTarget && onClose()}>
        <div style={s.modal}>
          <button style={s.closeBtn} onClick={onClose} aria-label="Хаах">✕</button>

          {/* Banner */}
          <div style={{ ...s.imgBanner, background: `linear-gradient(135deg, ${recipe.color[0]}, ${recipe.color[1]})` }}>
            <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 40% 35%, rgba(255,255,255,0.1), transparent 65%)' }} />
            <FoodImage recipe={recipe} size={140} />
            <div style={s.imgOverlay}>
              <span style={s.tag}>{recipe.categoryLabel}</span>
              <h2 style={s.title}>{recipe.name}</h2>
            </div>
          </div>

          <div style={s.body}>
            <div style={s.metaRow}>
              <span style={s.metaItem}>⏱ {recipe.time}</span>
              <span style={s.metaItem}>👥 {recipe.serves}</span>
              <span style={s.metaItem}>🔥 {recipe.diff}</span>
              <span style={s.metaItem}>🥗 {recipe.calories}</span>
            </div>

            <div style={s.cols}>
              <div>
                <p style={s.sectionTitle}>🥬 Орцнууд</p>
                <ul style={s.ingrList}>
                  {recipe.ingredients.map((ing, i) => (
                    <li key={i} style={s.ingrItem}>
                      <span style={s.dot} />
                      {ing}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <p style={s.sectionTitle}>👨‍🍳 Хийх арга</p>
                <ol style={s.stepList}>
                  {recipe.steps.map((step, i) => (
                    <li key={i} style={s.stepItem}>
                      <span style={s.stepNum}>{i + 1}</span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ol>
              </div>
            </div>

            <div style={s.tip}>💡 {recipe.tip}</div>
          </div>
        </div>
      </div>
    </>
  )
}
