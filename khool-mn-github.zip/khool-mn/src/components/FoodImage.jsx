import React from 'react'

const styles = {
  wrap: (color1, color2, size) => ({
    width: size, height: size,
    borderRadius: '50%',
    background: `radial-gradient(circle at 35% 35%, ${color2}, ${color1})`,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: size * 0.45,
    position: 'relative',
    overflow: 'hidden',
    flexShrink: 0,
  }),
  shine: {
    position: 'absolute', top: '8%', left: '15%',
    width: '30%', height: '20%',
    background: 'rgba(255,255,255,0.15)',
    borderRadius: '50%',
    transform: 'rotate(-30deg)',
  },
}

export default function FoodImage({ recipe, size = 80 }) {
  return (
    <div style={styles.wrap(recipe.color[0], recipe.color[1], size)}>
      <div style={styles.shine} />
      <span role="img" aria-label={recipe.name} style={{ lineHeight: 1, zIndex: 1 }}>
        {recipe.emoji}
      </span>
    </div>
  )
}
